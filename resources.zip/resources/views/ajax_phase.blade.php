@foreach($phases as $p)

    <option value="{{$p->id}}"> {{$p->title}}  </option>
 
@endforeach